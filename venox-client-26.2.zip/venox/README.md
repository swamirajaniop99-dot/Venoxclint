# VENOX CLIENT 26.2 — Phase 1

Fabric client mod for **Minecraft 26.2**. Purple / black / neon-blue UI, original branding, no code or assets from other clients.

| | |
|---|---|
| Minecraft | 26.2 |
| Fabric Loader | 0.19.5+ |
| Fabric API | 0.161.0+26.2 |
| Java | 25 |
| Gradle | 9.5.1 (Loom `1.17-SNAPSHOT`, non-remapping plugin `net.fabricmc.fabric-loom`) |

## Build

```bash
# needs JDK 25 and Gradle 9.5.1 (or run `gradle wrapper --gradle-version 9.5.1` once to create ./gradlew)
gradle build            # jar: build/libs/venox-client-1.0.0-phase1+26.2.jar
gradle runClient        # launches a dev client with the mod
```

## Install

1. Install Fabric Loader 0.19.5+ for Minecraft 26.2 (https://fabricmc.net/use/installer/) and Java 25.
2. Put **Fabric API 0.161.0+26.2** and `venox-client-*.jar` (not the `-sources` jar) into `.minecraft/mods/`.
3. Start the Fabric 26.2 profile.

## Controls (all rebindable in Options > Controls > VENOX CLIENT)

| Key | Action |
|---|---|
| Right Shift | Click GUI |
| Right Ctrl | HUD Editor |
| C (hold) | Zoom |
| unbound | one toggle key per module |

## Features in Phase 1

- **Click GUI**: categories, module search, expandable settings (toggle / slider / mode), animated, theme editor (4 presets + RGB sliders for accent, accent 2, background).
- **HUD Editor**: drag, edge/center snapping, scroll to resize, right-click resets size, chips to enable/disable elements, reset positions.
- **HUD**: FPS, CPS, Keystrokes, Armor, Coordinates.
- **Gameplay**: Toggle Sprint, Zoom, Fullbright.
- **Main menu**: Singleplayer, Multiplayer, Mods (real Fabric mod list), Options, VENOX Settings, Quit, account chip. Can be switched off in Click GUI > Theme.
- **Settings**: `.minecraft/config/venox/config.json`, auto-saved ~0.6 s after any change and on exit; a corrupt file is moved to `config.json.broken`.

## Architecture

```
dev.venox
  VenoxClient            entrypoint, keybinds, tick, HUD registration
  config/ConfigManager   JSON load / debounced autosave
  module/                Module, HudModule, Category, ModuleManager
    hud/ gameplay/       one class per module, no cross-references
  setting/               Bool / Number / Mode settings (auto JSON)
  gui/                   Click GUI, HUD editor, Draw toolkit, Theme, Logo
  menu/                  title screen, mods screen
  compat/ItemDraw        the one call site for the unverified item-draw API
```

Add a module: write a class extending `Module` or `HudModule`, add one line to `ModuleManager.init()`, add a `key.venox.module_<id>` line to `lang/en_us.json`. Its settings, saving, search, Click GUI card and keybind come for free.

## Verification status (honest)

Nothing here has been compiled or run yet: the environment this was written in has no network and no JDK 25. Treat the first `gradle build` as the real test.

**Confirmed against the Fabric 26.2 docs / 26.2 mods before use**
Non-remapping Loom plugin, Mojang names, Java 25, `GuiGraphicsExtractor` (`fill`, `fillGradient`, `outline`, `text`, `enableScissor`, `pose()` matrix stack), `Screen.extractRenderState`, `minecraft.gui.setScreen/screen()`, `HudElementRegistry.attachElementBefore` + `VanillaHudElements.CHAT`, `KeyMappingHelper.registerKeyMapping`, `KeyMapping.Category.register`, `Identifier`, `fabric-api` mod id, `MouseButtonEvent`/`KeyEvent` screen overrides.

**Not confirmed — first places to look if the build fails**
1. `compat/ItemDraw`: `g.item(...)` / `g.itemDecorations(...)` names.
2. `CharacterEvent.codepoint()`, `MouseButtonEvent.x()/y()/button()`, `KeyEvent.key()` accessor names (ClickGuiScreen, HudEditorScreen).
3. `KeyMapping.setDown(boolean)` (Toggle Sprint), `options.fov()` set/get (Zoom).
4. Screen constructors: `SelectWorldScreen(Screen)`, `JoinMultiplayerScreen(Screen)`, `OptionsScreen(Screen, Options)` and their packages (VenoxTitleScreen).
5. `minecraft.getUser().getName()`, `mc.getWindow().getGuiScaledWidth()/Height()`.
6. `ClientLifecycleEvents`/`ClientTickEvents` package paths (standard Fabric lifecycle v1).

Tip: `javap -p` on the decompiled jar in `~/.gradle/caches/fabric-loom/` is the fastest way to confirm any signature.

**Runtime behaviour that needs a human test**: GUI layout at several GUI scales, HUD scaling/clamping, title-screen replacement, Fullbright (client-side night vision), zoom restore after leaving the world.

**Known limits**: Zoom cannot go below FOV 30 (vanilla option range). Fullbright uses a client-side night-vision effect, not a gamma hack.

## Roadmap

- **Phase 2**: Potion HUD, Ping, Speed, Direction, Target HUD, custom crosshair, Toggle Sneak, Freelook, Auto GG, custom perspective, in-GUI keybind editor, module-position profiles.
- **Phase 3**: cosmetics screen, account screen, screenshot manager, custom fonts/backgrounds/GUI scale, performance pass.
