package dev.venox.util;

import java.util.ArrayDeque;

/** Counts press edges of two buttons and reports clicks within the last second. */
public final class ClickTracker {
    private final ArrayDeque<Long> left = new ArrayDeque<>();
    private final ArrayDeque<Long> right = new ArrayDeque<>();
    private boolean prevLeft, prevRight;

    public void update(boolean leftDown, boolean rightDown) {
        long now = System.currentTimeMillis();
        if (leftDown && !prevLeft) left.addLast(now);
        if (rightDown && !prevRight) right.addLast(now);
        prevLeft = leftDown;
        prevRight = rightDown;
        prune(left, now);
        prune(right, now);
    }

    public int left() { return left.size(); }
    public int right() { return right.size(); }

    private static void prune(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000L) q.pollFirst();
    }
}
