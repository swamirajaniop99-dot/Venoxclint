package dev.venox.util;

/** Frame-time based animation helpers. Safe to call tick() several times per frame. */
public final class Anim {
    private static long last = System.nanoTime();
    private static float dt = 0.016f;

    private Anim() {}

    public static void tick() {
        long now = System.nanoTime();
        long diff = now - last;
        if (diff > 2_000_000L) { // ignore repeat calls inside the same frame
            dt = Math.min(0.1f, diff / 1_000_000_000f);
            last = now;
        }
    }

    public static float dt() { return dt; }

    /** Exponential approach: smooth, frame-rate independent. */
    public static float approach(float cur, float target, float speed) {
        float k = 1f - (float) Math.exp(-speed * dt);
        float v = cur + (target - cur) * k;
        return Math.abs(target - v) < 0.001f ? target : v;
    }

    public static float ease(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float u = 1f - t;
        return 1f - u * u * u;
    }
}
