package dev.venox.menu;

import dev.venox.gui.Draw;
import dev.venox.gui.Hit;
import dev.venox.gui.Theme;
import dev.venox.util.Anim;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Lists the mods actually loaded by Fabric (top-level mods only, no bundled sub-modules). */
public final class ModsScreen extends Screen {
    private final Screen parent;
    private final List<ModContainer> mods = new ArrayList<>();
    private final List<Hit> hits = new ArrayList<>();
    private float scroll, scrollTarget;

    public ModsScreen(Screen parent) {
        super(Component.literal("Mods"));
        this.parent = parent;
        for (ModContainer m : FabricLoader.getInstance().getAllMods()) {
            if (m.getContainingMod().isPresent() || m.getMetadata().getId().equals("java")) continue;
            mods.add(m);
        }
        mods.sort(Comparator.comparing(m -> m.getMetadata().getName().toLowerCase()));
    }

    @Override public void onClose() { this.minecraft.gui.setScreen(parent); }
    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partial) {
        Anim.tick();
        hits.clear();
        g.fillGradient(0, 0, width, height, Draw.lerp(Theme.bg, Theme.accent, 0.12f), Theme.bg);
        int pw = Math.min(380, width - 20), px = (width - pw) / 2, top = 40, bottom = height - 40;
        Draw.glow(g, px, top, pw, bottom - top, 8, Theme.accent, 3);
        Draw.round(g, px, top, pw, bottom - top, 8, Theme.panel());
        Draw.gradientText(g, "Loaded Mods (" + mods.size() + ")", px + 12, top + 10, Theme.accent, Theme.accent2);
        Draw.hgradient(g, px + 8, top + 24, pw - 16, 1, Theme.accent, Theme.accent2);

        int ly = top + 30, lh = bottom - ly - 6;
        int rowH = 24, content = mods.size() * rowH;
        scrollTarget = Math.max(0, Math.min(Math.max(0, content - lh), scrollTarget));
        scroll = Anim.approach(scroll, scrollTarget, 18f);
        g.enableScissor(px + 4, ly, px + pw - 4, ly + lh);
        for (int i = 0; i < mods.size(); i++) {
            int y = ly + i * rowH - Math.round(scroll);
            if (y + rowH < ly || y > ly + lh) continue;
            var meta = mods.get(i).getMetadata();
            Draw.round(g, px + 8, y, pw - 16, rowH - 3, 5, Theme.panel2());
            Draw.text(g, meta.getName(), px + 16, y + 3, Theme.text());
            Draw.text(g, meta.getId(), px + 16, y + 12, Theme.dim());
            String v = meta.getVersion().getFriendlyString();
            Draw.text(g, v, px + pw - 16 - Draw.width(v), y + 7, Theme.accent2);
        }
        g.disableScissor();

        int bw = 100, bx = (width - bw) / 2, by = height - 30;
        boolean hov = Draw.inside(mx, my, bx, by, bw, 20);
        Draw.border(g, bx, by, bw, 20, 5, hov ? Theme.accent : Theme.line(), hov ? Theme.panel2() : Theme.panel());
        Draw.centered(g, "Back", width / 2, by + 6, hov ? 0xFFFFFFFF : Theme.text());
        Hit h = new Hit(bx, by, bw, 20);
        h.click = this::onClose;
        hits.add(h);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scrollTarget -= (float) sy * 24f;
        return true;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
        if (e.button() == 0) {
            for (Hit h : hits) if (h.contains(e.x(), e.y())) { h.click.run(); return true; }
        }
        return super.mouseClicked(e, doubleClick);
    }
}
