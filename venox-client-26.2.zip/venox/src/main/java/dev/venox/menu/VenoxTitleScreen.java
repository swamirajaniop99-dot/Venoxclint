package dev.venox.menu;

import dev.venox.VenoxClient;
import dev.venox.gui.ClickGuiScreen;
import dev.venox.gui.Draw;
import dev.venox.gui.Hit;
import dev.venox.gui.Logo;
import dev.venox.gui.Theme;
import dev.venox.util.Anim;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Original VENOX main menu: animated gradient, glow orbs, particles, logo, account chip. */
public final class VenoxTitleScreen extends Screen {
    private static final int COUNT = 70;

    private final List<Hit> hits = new ArrayList<>();
    private final float[] hover = new float[6];
    private final float[] px = new float[COUNT], py = new float[COUNT], ps = new float[COUNT], pz = new float[COUNT];
    private long openedAt;

    public VenoxTitleScreen() { super(Component.literal("VENOX CLIENT")); }

    @Override protected void init() {
        openedAt = System.currentTimeMillis();
        Random r = new Random(26);
        for (int i = 0; i < COUNT; i++) {
            px[i] = r.nextFloat(); py[i] = r.nextFloat();
            ps[i] = 0.01f + r.nextFloat() * 0.03f; pz[i] = 1 + r.nextInt(2);
        }
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partial) {
        Anim.tick();
        hits.clear();
        float t = (System.currentTimeMillis() - openedAt) / 1000f;
        float fade = Anim.ease(Math.min(1f, t / 0.6f));

        g.fillGradient(0, 0, width, height, Draw.lerp(Theme.bg, Theme.accent, 0.16f), Theme.bg);
        orb(g, (int) (width * (0.25f + 0.06f * Math.sin(t * 0.4))), (int) (height * (0.30f + 0.05f * Math.cos(t * 0.3))), 70, Theme.accent);
        orb(g, (int) (width * (0.78f + 0.05f * Math.cos(t * 0.35))), (int) (height * (0.70f + 0.06f * Math.sin(t * 0.45))), 80, Theme.accent2);
        for (int i = 0; i < COUNT; i++) {
            float y = ((py[i] - t * ps[i]) % 1f + 1f) % 1f;
            float a = 0.25f + 0.35f * (float) Math.abs(Math.sin(t + i));
            int sz = (int) pz[i];
            int x = (int) (px[i] * width), yy = (int) (y * height);
            g.fill(x, yy, x + sz, yy + sz, Draw.alpha(i % 2 == 0 ? Theme.accent2 : Theme.accent, a));
        }

        String[] labels = {"Singleplayer", "Multiplayer", "Mods", "Options", "VENOX Settings", "Quit Game"};
        Runnable[] actions = {
                () -> minecraft.gui.setScreen(new SelectWorldScreen(this)),
                () -> minecraft.gui.setScreen(new JoinMultiplayerScreen(this)),
                () -> minecraft.gui.setScreen(new ModsScreen(this)),
                () -> minecraft.gui.setScreen(new OptionsScreen(this, minecraft.options)),
                () -> minecraft.gui.setScreen(new ClickGuiScreen(this)),
                () -> minecraft.stop()};
        int bw = 210, bh = 24, gap = 6, total = labels.length * (bh + gap) - gap;
        int logoH = Math.max(34, Math.min(60, height / 7));
        int block = logoH + 34 + total;
        int top = Math.max(8, (height - block) / 2);
        int slide = Math.round((1f - fade) * 16f);

        Logo.mark(g, width / 2, top + slide, logoH);
        Logo.wordmark(g, width / 2, top + logoH + 8 + slide, 2f);
        Draw.centered(g, "CLIENT  |  " + VenoxClient.MC_VERSION, width / 2, top + logoH + 26 + slide, Theme.dim());

        int y0 = top + logoH + 40 + slide, bx = (width - bw) / 2;
        for (int i = 0; i < labels.length; i++) {
            int y = y0 + i * (bh + gap);
            boolean hov = Draw.inside(mx, my, bx, y, bw, bh);
            hover[i] = Anim.approach(hover[i], hov ? 1f : 0f, 16f);
            float h = hover[i];
            if (h > 0.02f) Draw.glow(g, bx, y, bw, bh, 6, Theme.accent, 2);
            Draw.border(g, bx, y, bw, bh, 6, Draw.lerp(Theme.line(), Theme.accent, h), Draw.lerp(Draw.alpha(Theme.panel(), 0.85f), Theme.panel2(), h));
            g.fillGradient(bx + 1, y + 5, bx + 3 + Math.round(2 * h), y + bh - 5, Theme.accent, Theme.accent2);
            Draw.centered(g, labels[i], width / 2 + Math.round(3 * h), y + (bh - 8) / 2, Draw.lerp(Theme.text(), 0xFFFFFFFF, h));
            Hit ht = new Hit(bx, y, bw, bh);
            ht.click = actions[i];
            hits.add(ht);
        }

        // account chip (bottom-left) and build label (bottom-right)
        String name = minecraft.getUser().getName();
        int cw = Draw.width(name) + 70;
        Draw.border(g, 8, height - 26, cw, 18, 5, Theme.line(), Draw.alpha(Theme.panel(), 0.9f));
        Draw.round(g, 14, height - 21, 8, 8, 4, 0xFF4ADE80);
        Draw.text(g, "Account", 28, height - 21, Theme.dim());
        Draw.text(g, name, 28 + Draw.width("Account "), height - 21, Theme.text());
        String build = "VENOX CLIENT " + VenoxClient.MC_VERSION + "  |  Fabric";
        Draw.text(g, build, width - 8 - Draw.width(build), height - 18, Theme.dim());
    }

    private void orb(GuiGraphicsExtractor g, int cx, int cy, int r, int color) {
        for (int i = 6; i >= 1; i--) {
            int rr = r * i / 6;
            Draw.round(g, cx - rr, cy - rr, rr * 2, rr * 2, rr, Draw.alpha(color, 0.035f));
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
        if (e.button() == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (h.contains(e.x(), e.y())) { h.click.run(); return true; }
            }
        }
        return super.mouseClicked(e, doubleClick);
    }
}
