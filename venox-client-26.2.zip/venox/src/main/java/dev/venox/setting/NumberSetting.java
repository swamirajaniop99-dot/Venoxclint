package dev.venox.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Locale;

public final class NumberSetting extends Setting<Double> {
    public final double min, max, step;

    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name, def);
        this.min = min; this.max = max; this.step = step;
    }

    private double fix(double v) {
        v = Math.max(min, Math.min(max, v));
        if (step > 0) v = min + Math.round((v - min) / step) * step;
        return Math.max(min, Math.min(max, Math.round(v * 10000d) / 10000d));
    }

    @Override public void set(Double v) { super.set(fix(v)); }

    public int getInt() { return (int) Math.round(value); }
    public float getFloat() { return value.floatValue(); }

    public String display() {
        return step >= 1 ? Integer.toString(getInt()) : String.format(Locale.ROOT, "%.2f", value);
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        try { if (e != null && e.isJsonPrimitive()) value = fix(e.getAsDouble()); } catch (RuntimeException ignored) {}
    }
}
