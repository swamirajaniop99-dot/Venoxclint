package dev.venox.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.venox.config.ConfigManager;

public final class ModeSetting extends Setting<String> {
    public final String[] modes;
    private int index;

    public ModeSetting(String name, String def, String... modes) {
        super(name, def);
        this.modes = modes;
        for (int i = 0; i < modes.length; i++) if (modes[i].equals(def)) index = i;
        this.value = modes[index];
    }

    public int index() { return index; }

    public void cycle(int dir) {
        index = Math.floorMod(index + dir, modes.length);
        value = modes[index];
        ConfigManager.markDirty();
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e == null || !e.isJsonPrimitive()) return;
        String s = e.getAsString();
        for (int i = 0; i < modes.length; i++) if (modes[i].equals(s)) { index = i; value = s; }
    }
}
