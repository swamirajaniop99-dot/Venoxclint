package dev.venox.setting;

import com.google.gson.JsonElement;
import dev.venox.config.ConfigManager;
import java.util.Objects;

public abstract class Setting<T> {
    public final String name;
    protected T value;

    protected Setting(String name, T def) { this.name = name; this.value = def; }

    public T get() { return value; }

    public void set(T v) {
        if (!Objects.equals(value, v)) { value = v; ConfigManager.markDirty(); }
    }

    public abstract JsonElement toJson();
    /** Must assign the field directly (no dirty flag) and ignore malformed input. */
    public abstract void fromJson(JsonElement e);
}
