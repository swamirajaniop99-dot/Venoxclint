package dev.venox.compat;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;

/**
 * UNVERIFIED against 26.2: the exact method names GuiGraphicsExtractor uses to draw an item and its
 * decorations. Everything else in the project uses calls confirmed in the Fabric 26.2 docs. If the
 * build fails here, this is the ONLY file that needs adjusting (see README, "Known risks").
 */
public final class ItemDraw {
    private ItemDraw() {}

    public static void draw(GuiGraphicsExtractor g, Font font, ItemStack stack, int x, int y) {
        g.item(stack, x, y);
        g.itemDecorations(font, stack, x, y);
    }
}
