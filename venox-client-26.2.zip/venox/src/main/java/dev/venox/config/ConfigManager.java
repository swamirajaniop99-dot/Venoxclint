package dev.venox.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.venox.VenoxClient;
import dev.venox.gui.Theme;
import dev.venox.module.ModuleManager;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import net.fabricmc.loader.api.FabricLoader;

/** JSON settings: .minecraft/config/venox/config.json. Auto-saves ~0.6 s after the last change and on exit. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("venox").resolve("config.json");

    public static boolean customMenu = true;

    private static boolean dirty, loading;
    private static long changedAt;

    private ConfigManager() {}

    public static void markDirty() {
        if (loading) return;
        dirty = true;
        changedAt = System.currentTimeMillis();
    }

    public static void tick() {
        if (dirty && System.currentTimeMillis() - changedAt > 600) save();
    }

    public static void load() {
        if (!Files.exists(FILE)) { save(); return; }
        loading = true;
        try (Reader r = Files.newBufferedReader(FILE)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            if (root.has("customMenu")) customMenu = root.get("customMenu").getAsBoolean();
            if (root.has("theme")) Theme.load(root.getAsJsonObject("theme"));
            if (root.has("modules")) ModuleManager.load(root.getAsJsonObject("modules"));
        } catch (Exception e) {
            VenoxClient.LOGGER.error("Config unreadable, keeping a backup and using defaults", e);
            try { Files.move(FILE, FILE.resolveSibling("config.json.broken"), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException ignored) {}
        } finally {
            loading = false;
        }
    }

    public static synchronized void save() {
        dirty = false;
        try {
            JsonObject root = new JsonObject();
            root.addProperty("version", 1);
            root.addProperty("customMenu", customMenu);
            root.add("theme", Theme.save());
            root.add("modules", ModuleManager.save());
            Files.createDirectories(FILE.getParent());
            Path tmp = FILE.resolveSibling("config.json.tmp");
            Files.writeString(tmp, GSON.toJson(root));
            Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            VenoxClient.LOGGER.error("Could not save config", e);
        }
    }
}
