package dev.venox.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Small immediate-mode drawing toolkit built only on fill / fillGradient / text / outline. */
public final class Draw {
    private Draw() {}

    public static int alpha(int argb, float a) {
        int al = Math.max(0, Math.min(255, Math.round(((argb >>> 24) & 0xFF) * a)));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bgc = (b >> 8) & 255, bb = b & 255;
        int ra = Math.round(aa + (ba - aa) * t);
        int rr = Math.round(ar + (br - ar) * t);
        int rg = Math.round(ag + (bgc - ag) * t);
        int rb = Math.round(ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Filled rounded rectangle (rows are inset per corner, so it works with translucent colors). */
    public static void round(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, c); return; }
        g.fill(x, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * (double) r - dy * dy));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, c);
            g.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, c);
        }
    }

    public static void border(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int border, int fill) {
        round(g, x, y, w, h, r, border);
        round(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    /** Soft glow made of stacked translucent rounded rects. */
    public static void glow(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color, int layers) {
        for (int i = layers; i >= 1; i--) {
            float a = 0.05f * (1f - (i - 1) / (float) layers);
            round(g, x - i * 2, y - i * 2, w + i * 4, h + i * 4, r + i * 2, alpha(color, a));
        }
    }

    /** Horizontal gradient built from vertical slices. */
    public static void hgradient(GuiGraphicsExtractor g, int x, int y, int w, int h, int c1, int c2) {
        int step = 2;
        for (int i = 0; i < w; i += step) {
            g.fill(x + i, y, Math.min(x + w, x + i + step), y + h, lerp(c1, c2, i / (float) Math.max(1, w - 1)));
        }
    }

    public static void toggle(GuiGraphicsExtractor g, int x, int y, float p) {
        round(g, x, y, 24, 12, 6, lerp(Theme.line(), Theme.accent, p));
        round(g, x + 2 + Math.round(12 * p), y + 2, 8, 8, 4, 0xFFFFFFFF);
    }

    public static int width(String s) { return Minecraft.getInstance().font.width(s); }

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(Minecraft.getInstance().font, s, x, y, color, true);
    }

    public static void centered(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        text(g, s, cx - width(s) / 2, y, color);
    }

    public static void gradientText(GuiGraphicsExtractor g, String s, int x, int y, int c1, int c2) {
        int cx = x;
        for (int i = 0; i < s.length(); i++) {
            String ch = String.valueOf(s.charAt(i));
            text(g, ch, cx, y, lerp(c1, c2, s.length() <= 1 ? 0f : i / (float) (s.length() - 1)));
            cx += width(ch);
        }
    }
}
