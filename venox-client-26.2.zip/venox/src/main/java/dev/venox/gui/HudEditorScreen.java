package dev.venox.gui;

import dev.venox.config.ConfigManager;
import dev.venox.module.HudModule;
import dev.venox.module.Module;
import dev.venox.module.ModuleManager;
import dev.venox.util.Anim;
import dev.venox.VenoxClient;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Drag HUD elements, scroll to resize, right-click to reset size, chips at the top toggle modules. */
public final class HudEditorScreen extends Screen {
    private static final int SNAP = 5;

    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private HudModule dragging;
    private int offX, offY;
    private boolean snapX, snapY;

    public HudEditorScreen(Screen parent) {
        super(Component.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() {
        ConfigManager.markDirty();
        this.minecraft.gui.setScreen(parent);
    }

    private List<HudModule> huds() {
        List<HudModule> out = new ArrayList<>();
        for (Module m : ModuleManager.all()) if (m instanceof HudModule h) out.add(h);
        return out;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partial) {
        Anim.tick();
        hits.clear();
        g.fill(0, 0, width, height, 0x66000000);

        if (dragging != null) {
            if (snapX) g.fill(width / 2, 0, width / 2 + 1, height, Draw.alpha(Theme.accent2, 0.7f));
            if (snapY) g.fill(0, height / 2, width, height / 2 + 1, Draw.alpha(Theme.accent2, 0.7f));
        }

        for (HudModule h : huds()) {
            if (!h.isEnabled()) continue;
            h.render(g, minecraft);
            boolean hov = Draw.inside(mx, my, h.x, h.y, h.scaledWidth(), h.scaledHeight());
            int c = h == dragging ? Theme.accent2 : hov ? Theme.accent : Draw.alpha(Theme.accent, 0.5f);
            g.outline(h.x - 1, h.y - 1, h.scaledWidth() + 2, h.scaledHeight() + 2, c);
            if (hov || h == dragging) {
                int ly = h.y > 12 ? h.y - 11 : h.y + h.scaledHeight() + 3;
                Draw.text(g, h.name + "  x" + String.format("%.1f", h.scale), h.x, ly, 0xFFFFFFFF);
            }
        }

        // module chips
        List<HudModule> all = huds();
        int total = 0;
        for (HudModule h : all) total += Draw.width(h.name) + 26;
        int x = (width - total) / 2;
        for (HudModule h : all) {
            int w = Draw.width(h.name) + 22;
            boolean on = h.isEnabled();
            Draw.border(g, x, 6, w, 18, 5, on ? Theme.accent : Theme.line(), Theme.panel());
            Draw.round(g, x + 6, 12, 6, 6, 3, on ? Theme.accent2 : Theme.line());
            Draw.text(g, h.name, x + 16, 11, on ? 0xFFFFFFFF : Theme.dim());
            Hit ht = new Hit(x, 6, w, 18);
            ht.click = h::toggle;
            hits.add(ht);
            x += w + 4;
        }

        // bottom bar
        Draw.centered(g, "Drag to move  |  Scroll to resize  |  Right-click to reset size", width / 2, height - 44, Theme.dim());
        button(g, mx, my, width / 2 - 104, height - 30, 100, 20, "Reset positions", ModuleManager::resetHudPositions);
        button(g, mx, my, width / 2 + 4, height - 30, 100, 20, "Done", this::onClose);
    }

    private void button(GuiGraphicsExtractor g, int mx, int my, int x, int y, int w, int h, String label, Runnable r) {
        boolean hov = Draw.inside(mx, my, x, y, w, h);
        Draw.border(g, x, y, w, h, 5, hov ? Theme.accent : Theme.line(), hov ? Theme.panel2() : Theme.panel());
        Draw.centered(g, label, x + w / 2, y + (h - 8) / 2, hov ? 0xFFFFFFFF : Theme.text());
        Hit ht = new Hit(x, y, w, h);
        ht.click = r;
        hits.add(ht);
    }

    private HudModule moduleAt(double mx, double my) {
        List<HudModule> list = huds();
        for (int i = list.size() - 1; i >= 0; i--) {
            HudModule h = list.get(i);
            if (h.isEnabled() && Draw.inside(mx, my, h.x, h.y, h.scaledWidth(), h.scaledHeight())) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
        double mx = e.x(), my = e.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my) && e.button() == 0) { h.click.run(); return true; }
        }
        HudModule m = moduleAt(mx, my);
        if (m != null) {
            if (e.button() == 0) { dragging = m; offX = (int) mx - m.x; offY = (int) my - m.y; }
            else if (e.button() == 1) { m.scale = 1f; ConfigManager.markDirty(); }
            return true;
        }
        return super.mouseClicked(e, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging == null) return super.mouseDragged(e, dx, dy);
        int nx = (int) e.x() - offX, ny = (int) e.y() - offY;
        int sw = dragging.scaledWidth(), sh = dragging.scaledHeight();
        snapX = Math.abs(nx + sw / 2 - width / 2) <= SNAP;
        snapY = Math.abs(ny + sh / 2 - height / 2) <= SNAP;
        if (snapX) nx = width / 2 - sw / 2;
        if (snapY) ny = height / 2 - sh / 2;
        if (Math.abs(nx) <= SNAP) nx = 0;
        if (Math.abs(ny) <= SNAP) ny = 0;
        if (Math.abs(nx + sw - width) <= SNAP) nx = width - sw;
        if (Math.abs(ny + sh - height) <= SNAP) ny = height - sh;
        dragging.x = nx;
        dragging.y = ny;
        dragging.clamp(minecraft);
        ConfigManager.markDirty();
        return true;
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        dragging = null;
        snapX = snapY = false;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        HudModule m = moduleAt(mx, my);
        if (m == null) return super.mouseScrolled(mx, my, sx, sy);
        m.scale = Math.max(0.5f, Math.min(3f, m.scale + (float) sy * 0.1f));
        m.clamp(minecraft);
        ConfigManager.markDirty();
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        if (VenoxClient.openHudEditor.matches(e)) { onClose(); return true; }
        return super.keyPressed(e);
    }
}
