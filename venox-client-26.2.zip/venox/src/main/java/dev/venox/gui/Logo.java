package dev.venox.gui;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Original VENOX mark: a gradient "V" built from diagonal strokes, plus wordmark. */
public final class Logo {
    private Logo() {}

    /** Draws the V mark centered on cx, top at y. size = height in px. */
    public static void mark(GuiGraphicsExtractor g, int cx, int y, int size) {
        int half = size / 2;
        int thick = Math.max(3, size / 5);
        for (int row = 0; row < size; row++) {
            float t = row / (float) (size - 1);
            int off = Math.round(half * (1f - t));
            int c = Draw.lerp(Theme.accent, Theme.accent2, t);
            g.fill(cx - off - thick, y + row, cx - off + thick / 2, y + row + 1, c);
            g.fill(cx + off - thick / 2, y + row, cx + off + thick, y + row + 1, c);
        }
    }

    /** Wordmark "VENOX" with letter spacing at scale s. */
    public static void wordmark(GuiGraphicsExtractor g, int cx, int y, float s) {
        String word = "V E N O X";
        int w = Math.round(Draw.width(word) * s);
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) (cx - w / 2), (float) y);
        pose.scale(s, s);
        Draw.gradientText(g, word, 0, 0, Theme.accent, Theme.accent2);
        pose.popMatrix();
    }
}
