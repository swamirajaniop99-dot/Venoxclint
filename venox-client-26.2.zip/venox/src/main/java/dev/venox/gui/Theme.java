package dev.venox.gui;

import com.google.gson.JsonObject;
import dev.venox.config.ConfigManager;
import java.util.List;

/** Global theme state. Purple / black / neon blue by default. */
public final class Theme {
    public record Preset(String name, int accent, int accent2, int bg) {}

    public static final List<Preset> PRESETS = List.of(
            new Preset("VENOX", 0xFF8B5CF6, 0xFF00D4FF, 0xFF0B0A12),
            new Preset("Nightfall", 0xFF6366F1, 0xFF38BDF8, 0xFF070B1A),
            new Preset("Neon Pulse", 0xFFD946EF, 0xFF22D3EE, 0xFF0D0713),
            new Preset("Void", 0xFF7C3AED, 0xFFA78BFA, 0xFF050507));

    public static int accent, accent2, bg;
    public static String preset = "VENOX";

    static { apply(PRESETS.get(0)); }

    private Theme() {}

    public static void apply(Preset p) {
        accent = p.accent();
        accent2 = p.accent2();
        bg = p.bg();
        preset = p.name();
        ConfigManager.markDirty();
    }

    public static void setAccent(int c) { accent = c | 0xFF000000; preset = "Custom"; ConfigManager.markDirty(); }
    public static void setAccent2(int c) { accent2 = c | 0xFF000000; preset = "Custom"; ConfigManager.markDirty(); }
    public static void setBg(int c) { bg = c | 0xFF000000; preset = "Custom"; ConfigManager.markDirty(); }

    public static int panel() { return Draw.lerp(bg, 0xFFFFFFFF, 0.05f); }
    public static int panel2() { return Draw.lerp(bg, 0xFFFFFFFF, 0.10f); }
    public static int line() { return Draw.lerp(bg, 0xFFFFFFFF, 0.18f); }
    public static int text() { return 0xFFEDEBFF; }
    public static int dim() { return 0xFF8E8AA8; }

    public static JsonObject save() {
        JsonObject o = new JsonObject();
        o.addProperty("preset", preset);
        o.addProperty("accent", hex(accent));
        o.addProperty("accent2", hex(accent2));
        o.addProperty("background", hex(bg));
        return o;
    }

    public static void load(JsonObject o) {
        if (o == null) return;
        if (o.has("preset")) preset = o.get("preset").getAsString();
        accent = parse(o, "accent", accent);
        accent2 = parse(o, "accent2", accent2);
        bg = parse(o, "background", bg);
    }

    private static String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    private static int parse(JsonObject o, String key, int fallback) {
        try {
            if (o.has(key)) return Integer.parseInt(o.get(key).getAsString().substring(1), 16) | 0xFF000000;
        } catch (RuntimeException ignored) {}
        return fallback;
    }
}
