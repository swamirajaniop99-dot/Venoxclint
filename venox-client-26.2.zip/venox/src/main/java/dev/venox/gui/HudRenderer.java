package dev.venox.gui;

import dev.venox.module.HudModule;
import dev.venox.module.Module;
import dev.venox.module.ModuleManager;
import dev.venox.util.Anim;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class HudRenderer {
    private HudRenderer() {}

    public static void render(GuiGraphicsExtractor g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.gui.screen() instanceof HudEditorScreen) return; // the editor draws them itself
        Anim.tick();
        for (Module m : ModuleManager.all()) {
            if (m.isHud() && m.isEnabled()) ((HudModule) m).render(g, mc);
        }
    }
}
