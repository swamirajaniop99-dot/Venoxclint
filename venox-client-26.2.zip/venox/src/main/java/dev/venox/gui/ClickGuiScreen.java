package dev.venox.gui;

import dev.venox.config.ConfigManager;
import dev.venox.module.Category;
import dev.venox.module.Module;
import dev.venox.module.ModuleManager;
import dev.venox.setting.BoolSetting;
import dev.venox.setting.ModeSetting;
import dev.venox.setting.NumberSetting;
import dev.venox.setting.Setting;
import dev.venox.util.Anim;
import dev.venox.VenoxClient;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** VENOX Click GUI: categories, module search, expandable settings, theme editor. Immediate-mode with hit regions. */
public final class ClickGuiScreen extends Screen {
    private static final int SET_H = 20;
    private static int lastTab = 0;

    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private Hit active;
    private int tab = lastTab;
    private String query = "";
    private boolean searchFocused;
    private float scroll, scrollTarget, contentH, tabY = -1f;
    private final Map<Module, Float> expandP = new HashMap<>();
    private final Map<Module, Float> onP = new HashMap<>();
    private final Map<Setting<?>, Float> boolP = new HashMap<>();
    private final Set<Module> expanded = new HashSet<>();
    private long openedAt;
    private int cx, cy, cw, ch;

    public ClickGuiScreen(Screen parent) {
        super(Component.literal("VENOX"));
        this.parent = parent;
    }

    private int themeTab() { return Category.values().length; }

    @Override protected void init() { openedAt = System.currentTimeMillis(); }
    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() {
        ConfigManager.markDirty();
        this.minecraft.gui.setScreen(parent);
    }

    private Hit hit(int x, int y, int w, int h) {
        Hit ht = new Hit(x, y, w, h);
        ht.clipY0 = cy;
        ht.clipY1 = cy + ch;
        hits.add(ht);
        return ht;
    }

    private Hit fixed(int x, int y, int w, int h) {
        Hit ht = new Hit(x, y, w, h);
        hits.add(ht);
        return ht;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float partial) {
        Anim.tick();
        hits.clear();
        float open = Anim.ease(Math.min(1f, (System.currentTimeMillis() - openedAt) / 220f));
        g.fillGradient(0, 0, width, height, Draw.alpha(0xFF000000, 0.35f * open), Draw.alpha(0xFF000000, 0.72f * open));

        int ww = Math.min(500, width - 16), wh = Math.min(310, height - 16);
        int wx = (width - ww) / 2, wy = (height - wh) / 2 + Math.round((1f - open) * 14f);
        Draw.glow(g, wx, wy, ww, wh, 10, Theme.accent, 5);
        Draw.round(g, wx, wy, ww, wh, 8, Theme.bg);

        // header
        Draw.round(g, wx + 1, wy + 1, ww - 2, 34, 7, Theme.panel());
        Draw.hgradient(g, wx + 8, wy + 36, ww - 16, 1, Theme.accent, Theme.accent2);
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate(wx + 14f, wy + 10f);
        pose.scale(1.5f, 1.5f);
        Draw.gradientText(g, "VENOX", 0, 0, Theme.accent, Theme.accent2);
        pose.popMatrix();
        Draw.text(g, "CLIENT " + VenoxClient.MC_VERSION, wx + 14 + Math.round(Draw.width("VENOX") * 1.5f) + 6, wy + 17, Theme.dim());

        // search box
        int sbw = Math.min(160, ww - 220), sbx = wx + ww - 14 - sbw, sby = wy + 9;
        Draw.border(g, sbx, sby, sbw, 18, 4, searchFocused ? Theme.accent : Theme.line(), Theme.panel2());
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = query.isEmpty() && !searchFocused ? "Search modules..." : query + (searchFocused && blink ? "_" : "");
        Draw.text(g, shown, sbx + 6, sby + 5, query.isEmpty() ? Theme.dim() : Theme.text());
        fixed(sbx, sby, sbw, 18).click = () -> searchFocused = true;

        // sidebar
        int sx0 = wx + 8, sy0 = wy + 46;
        Category[] cats = Category.values();
        float target = sy0 + tab * 26;
        tabY = tabY < 0 ? target : Anim.approach(tabY, target, 16f);
        int ty = Math.round(tabY);
        Draw.round(g, sx0, ty, 104, 22, 5, Draw.alpha(Theme.accent, 0.28f));
        g.fillGradient(sx0, ty + 4, sx0 + 2, ty + 18, Theme.accent, Theme.accent2);
        for (int i = 0; i <= cats.length; i++) {
            String label = i < cats.length ? cats[i].label : "Theme";
            final int idx = i;
            Draw.text(g, label, sx0 + 12, sy0 + i * 26 + 7, i == tab ? 0xFFFFFFFF : Theme.dim());
            fixed(sx0, sy0 + i * 26, 104, 22).click = () -> {
                tab = idx; lastTab = idx; query = ""; scrollTarget = 0; scroll = 0;
            };
        }
        int by = wy + wh - 32;
        button(g, mx, my, sx0, by - 28, 104, 22, "HUD Editor", () -> this.minecraft.gui.setScreen(new HudEditorScreen(this)));
        button(g, mx, my, sx0, by, 104, 22, "Done", this::onClose);

        cx = wx + 120; cy = wy + 44; cw = ww - 128; ch = wh - 52;
        if (query.isEmpty() && tab == themeTab()) renderTheme(g, mx, my);
        else renderModules(g, mx, my);
    }

    private void button(GuiGraphicsExtractor g, int mx, int my, int x, int y, int w, int h, String label, Runnable r) {
        boolean hov = Draw.inside(mx, my, x, y, w, h);
        Draw.border(g, x, y, w, h, 5, hov ? Theme.accent : Theme.line(), hov ? Theme.panel2() : Theme.panel());
        Draw.centered(g, label, x + w / 2, y + (h - 8) / 2, hov ? 0xFFFFFFFF : Theme.text());
        fixed(x, y, w, h).click = r;
    }

    // ---------------------------------------------------------------- modules

    private int settingsHeight(Module m) { return m.settings.size() * SET_H + 28; }

    private void renderModules(GuiGraphicsExtractor g, int mx, int my) {
        List<Module> list = query.isEmpty() ? ModuleManager.byCategory(Category.values()[tab]) : ModuleManager.search(query);
        g.enableScissor(cx, cy, cx + cw, cy + ch);
        float yy = cy - scroll;
        if (list.isEmpty()) Draw.text(g, "No modules found", cx + 6, cy + 8, Theme.dim());
        for (Module m : list) {
            float p = Anim.approach(expandP.getOrDefault(m, 0f), expanded.contains(m) ? 1f : 0f, 14f);
            expandP.put(m, p);
            float on = m.isEnabled() ? 1f : 0f;
            float op = Anim.approach(onP.getOrDefault(m, on), on, 16f);
            onP.put(m, op);
            int rowH = 34 + Math.round(p * settingsHeight(m));
            int ry = Math.round(yy), rw = cw - 6;
            if (ry + rowH >= cy && ry <= cy + ch) drawCard(g, m, ry, rw, rowH, p, op);
            yy += rowH + 4;
        }
        contentH = yy + scroll - cy;
        g.disableScissor();
        float max = Math.max(0f, contentH - ch);
        scrollTarget = Math.max(0f, Math.min(max, scrollTarget));
        scroll = Anim.approach(scroll, scrollTarget, 18f);
        if (max > 0) { // scrollbar
            int bh = Math.max(16, Math.round(ch * ch / contentH));
            int bpos = cy + Math.round((ch - bh) * (scroll / max));
            Draw.round(g, cx + cw - 3, bpos, 3, bh, 1, Draw.alpha(Theme.accent, 0.6f));
        }
    }

    private void drawCard(GuiGraphicsExtractor g, Module m, int ry, int rw, int rowH, float p, float op) {
        Draw.round(g, cx, ry, rw, rowH, 6, Draw.lerp(Theme.panel(), Theme.panel2(), p));
        if (op > 0.01f) g.fillGradient(cx, ry + 5, cx + 2, ry + 27, Draw.alpha(Theme.accent, op), Draw.alpha(Theme.accent2, op));
        Draw.text(g, m.name, cx + 10, ry + 7, Draw.lerp(Theme.text(), 0xFFFFFFFF, op));
        Draw.text(g, m.description, cx + 10, ry + 18, Theme.dim());
        int swx = cx + rw - 34, swy = ry + 10;
        Draw.toggle(g, swx, swy, op);
        Draw.text(g, expanded.contains(m) ? "v" : ">", swx - 14, ry + 11, Theme.dim());

        hit(cx, ry, rw - 44, 30).click = () -> { if (!expanded.remove(m)) expanded.add(m); };
        hit(cx, ry, rw - 44, 30).right = m::toggle;
        hit(swx - 4, ry + 6, 32, 20).click = m::toggle;

        if (p > 0.02f) {
            g.enableScissor(cx, ry + 30, cx + rw, ry + rowH);
            int sy = ry + 34;
            for (Setting<?> s : m.settings) { drawSetting(g, s, cx, sy, rw, p > 0.95f); sy += SET_H; }
            String key = m.toggleKey != null ? m.toggleKey.getTranslatedKeyMessage().getString() : "None";
            Draw.text(g, "Keybind", cx + 10, sy + 2, Theme.text());
            Draw.text(g, key, cx + rw - 10 - Draw.width(key), sy + 2, Theme.accent2);
            Draw.text(g, "Rebind in Options > Controls > Key Binds", cx + 10, sy + 14, Theme.dim());
            g.disableScissor();
        }
    }

    private void drawSetting(GuiGraphicsExtractor g, Setting<?> s, int x, int y, int w, boolean live) {
        Draw.text(g, s.name, x + 10, y + 6, Theme.text());
        int right = x + w - 10;
        if (s instanceof BoolSetting b) {
            float t = b.get() ? 1f : 0f;
            float p = Anim.approach(boolP.getOrDefault(s, t), t, 18f);
            boolP.put(s, p);
            int swx = right - 24;
            Draw.toggle(g, swx, y + 4, p);
            if (live) hit(swx - 2, y + 2, 28, 16).click = () -> b.set(!b.get());
        } else if (s instanceof NumberSetting n) {
            int tw = 90, tx = right - tw - 34;
            double frac = (n.get() - n.min) / (n.max - n.min);
            Draw.round(g, tx, y + 8, tw, 4, 2, Theme.line());
            Draw.round(g, tx, y + 8, Math.max(3, (int) (tw * frac)), 4, 2, Theme.accent);
            Draw.round(g, tx + (int) (tw * frac) - 3, y + 5, 6, 10, 3, 0xFFFFFFFF);
            String vs = n.display();
            Draw.text(g, vs, right - Draw.width(vs), y + 6, Theme.accent2);
            if (live) {
                Hit h = hit(tx - 4, y + 2, tw + 8, 16);
                h.drag = mxv -> n.set(n.min + Math.max(0, Math.min(1, (mxv - tx) / (double) tw)) * (n.max - n.min));
            }
        } else if (s instanceof ModeSetting ms) {
            String t = ms.get();
            int tw = Draw.width(t) + 16;
            Draw.round(g, right - tw, y + 2, tw, 16, 4, Theme.line());
            Draw.centered(g, t, right - tw / 2, y + 6, Theme.text());
            if (live) {
                Hit h = hit(right - tw, y + 2, tw, 16);
                h.click = () -> ms.cycle(1);
                h.right = () -> ms.cycle(-1);
            }
        }
    }

    // ------------------------------------------------------------------ theme

    private void renderTheme(GuiGraphicsExtractor g, int mx, int my) {
        g.enableScissor(cx, cy, cx + cw, cy + ch);
        Draw.text(g, "Presets", cx + 4, cy + 2, Theme.dim());
        int chipW = (cw - 6 - 3 * 6) / 4;
        for (int i = 0; i < Theme.PRESETS.size(); i++) {
            Theme.Preset p = Theme.PRESETS.get(i);
            int x = cx + 4 + i * (chipW + 6), y = cy + 14;
            boolean sel = Theme.preset.equals(p.name());
            Draw.border(g, x, y, chipW, 30, 5, sel ? Theme.accent : Theme.line(), Theme.panel());
            Draw.hgradient(g, x + 6, y + 6, chipW - 12, 4, p.accent(), p.accent2());
            Draw.centered(g, p.name(), x + chipW / 2, y + 16, sel ? 0xFFFFFFFF : Theme.text());
            hit(x, y, chipW, 30).click = () -> Theme.apply(p);
        }
        int colY = cy + 54, colW = (cw - 6 - 16) / 3;
        colorGroup(g, "Accent", cx + 4, colY, colW, () -> Theme.accent, Theme::setAccent);
        colorGroup(g, "Accent 2", cx + 4 + colW + 8, colY, colW, () -> Theme.accent2, Theme::setAccent2);
        colorGroup(g, "Background", cx + 4 + 2 * (colW + 8), colY, colW, () -> Theme.bg, Theme::setBg);

        int ry = colY + 112;
        Draw.round(g, cx + 4, ry, cw - 14, 26, 6, Theme.panel());
        Draw.text(g, "Custom main menu", cx + 14, ry + 9, Theme.text());
        float t = ConfigManager.customMenu ? 1f : 0f;
        Draw.toggle(g, cx + cw - 14 - 40, ry + 7, t);
        hit(cx + cw - 14 - 44, ry + 4, 32, 20).click = () -> { ConfigManager.customMenu = !ConfigManager.customMenu; ConfigManager.markDirty(); };
        Draw.centered(g, "Preset: " + Theme.preset, cx + cw / 2, ry + 34, Theme.dim());
        g.disableScissor();
    }

    private void colorGroup(GuiGraphicsExtractor g, String title, int x, int y, int w, IntSupplier get, IntConsumer set) {
        int c = get.getAsInt();
        Draw.round(g, x, y, w, 104, 6, Theme.panel());
        Draw.text(g, title, x + 8, y + 7, Theme.text());
        Draw.round(g, x + w - 26, y + 6, 18, 10, 3, c | 0xFF000000);
        String[] names = {"R", "G", "B"};
        int[] shifts = {16, 8, 0};
        int[] cols = {0xFFF87171, 0xFF4ADE80, 0xFF60A5FA};
        for (int i = 0; i < 3; i++) {
            final int sh = shifts[i];
            int val = (c >> sh) & 255;
            int sy = y + 26 + i * 22, tx = x + 22, tw = w - 22 - 34;
            Draw.text(g, names[i], x + 8, sy, Theme.dim());
            Draw.round(g, tx, sy + 2, tw, 4, 2, Theme.line());
            Draw.round(g, tx, sy + 2, Math.max(3, tw * val / 255), 4, 2, cols[i]);
            Draw.round(g, tx + tw * val / 255 - 3, sy - 1, 6, 10, 3, 0xFFFFFFFF);
            Draw.text(g, Integer.toString(val), x + w - 8 - Draw.width(Integer.toString(val)), sy, Theme.accent2);
            Hit h = hit(tx - 3, sy - 3, tw + 6, 16);
            h.drag = mxv -> {
                int v = (int) Math.round(Math.max(0, Math.min(1, (mxv - tx) / (double) tw)) * 255);
                int cur = get.getAsInt();
                set.accept(((cur & ~(255 << sh)) | (v << sh)) | 0xFF000000);
            };
        }
        Draw.text(g, String.format("#%06X", c & 0xFFFFFF), x + 8, y + 92, Theme.dim());
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean doubleClick) {
        double mx = e.x(), my = e.y();
        int b = e.button();
        searchFocused = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(mx, my)) continue;
            if (b == 0) {
                active = h;
                if (h.drag != null) h.drag.accept(mx);
                if (h.click != null) h.click.run();
            } else if (b == 1 && h.right != null) {
                h.right.run();
            }
            return true;
        }
        return super.mouseClicked(e, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (active != null && active.drag != null) { active.drag.accept(e.x()); return true; }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) {
        active = null;
        return super.mouseReleased(e);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        scrollTarget -= (float) sy * 28f;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent e) {
        if (searchFocused) {
            if (e.key() == GLFW.GLFW_KEY_ESCAPE) { searchFocused = false; return true; }
            if (e.key() == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
                scrollTarget = 0;
                return true;
            }
            return true;
        }
        if (VenoxClient.openGui.matches(e)) { onClose(); return true; }
        return super.keyPressed(e);
    }

    @Override
    public boolean charTyped(CharacterEvent e) {
        if (!searchFocused || e.codepoint() < 32 || query.length() >= 24) return false;
        query += new String(Character.toChars(e.codepoint()));
        scrollTarget = 0;
        scroll = 0;
        return true;
    }
}
