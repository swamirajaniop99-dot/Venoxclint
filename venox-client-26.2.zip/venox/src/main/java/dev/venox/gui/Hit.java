package dev.venox.gui;

import java.util.function.DoubleConsumer;

/** A clickable region collected while rendering (immediate-mode GUI). */
public final class Hit {
    public final int x, y, w, h;
    public Runnable click, right;
    public DoubleConsumer drag;
    public int clipY0 = Integer.MIN_VALUE, clipY1 = Integer.MAX_VALUE;

    public Hit(int x, int y, int w, int h) { this.x = x; this.y = y; this.w = w; this.h = h; }

    public boolean contains(double mx, double my) {
        return mx >= x && mx < x + w && my >= y && my < y + h && my >= clipY0 && my < clipY1;
    }
}
