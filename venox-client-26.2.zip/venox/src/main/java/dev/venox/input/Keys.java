package dev.venox.input;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

/** Registers vanilla key mappings (visible and rebindable in Options > Controls). */
public final class Keys {
    public static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("venox", "main"));

    private Keys() {}

    public static KeyMapping create(String id, int glfwKey) {
        return KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.venox." + id, InputConstants.Type.KEYSYM, glfwKey, CATEGORY));
    }
}
