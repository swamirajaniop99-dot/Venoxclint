package dev.venox;

import dev.venox.config.ConfigManager;
import dev.venox.gui.ClickGuiScreen;
import dev.venox.gui.HudEditorScreen;
import dev.venox.gui.HudRenderer;
import dev.venox.input.Keys;
import dev.venox.menu.VenoxTitleScreen;
import dev.venox.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class VenoxClient implements ClientModInitializer {
    public static final String MOD_ID = "venox";
    public static final String NAME = "VENOX CLIENT";
    public static final String MC_VERSION = "26.2";
    public static final Logger LOGGER = LoggerFactory.getLogger("VENOX");

    public static KeyMapping openGui, openHudEditor;

    @Override
    public void onInitializeClient() {
        openGui = Keys.create("click_gui", GLFW.GLFW_KEY_RIGHT_SHIFT);
        openHudEditor = Keys.create("hud_editor", GLFW.GLFW_KEY_RIGHT_CONTROL);

        ModuleManager.init();   // creates modules + their key mappings
        ConfigManager.load();   // then restores saved state

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "hud"), HudRenderer::render);

        ClientTickEvents.END_CLIENT_TICK.register(VenoxClient::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ModuleManager.shutdown();
            ConfigManager.save();
        });
        LOGGER.info("{} {} initialised", NAME, MC_VERSION);
    }

    private static void tick(Minecraft mc) {
        while (openGui.consumeClick()) {
            if (mc.gui.screen() == null) mc.gui.setScreen(new ClickGuiScreen(null));
        }
        while (openHudEditor.consumeClick()) {
            if (mc.gui.screen() == null) mc.gui.setScreen(new HudEditorScreen(null));
        }
        Screen cur = mc.gui.screen();
        if (cur != null && cur.getClass() == TitleScreen.class && ConfigManager.customMenu) {
            mc.gui.setScreen(new VenoxTitleScreen());
        }
        ModuleManager.tick(mc);
        ConfigManager.tick();
    }
}
