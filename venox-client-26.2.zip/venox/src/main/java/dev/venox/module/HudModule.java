package dev.venox.module;

import com.google.gson.JsonObject;
import dev.venox.config.ConfigManager;
import dev.venox.gui.Draw;
import dev.venox.gui.Theme;
import dev.venox.setting.BoolSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** A draggable, scalable HUD element. Position is stored in GUI-scaled pixels (top-left anchor). */
public abstract class HudModule extends Module {
    protected static final int PAD = 4;

    public int x, y;
    public float scale = 1f;
    private final int defX, defY;
    protected final BoolSetting background;

    protected HudModule(String id, String name, String desc, int x, int y, boolean enabled, boolean hasBackground) {
        super(id, name, desc, Category.HUD, enabled);
        this.x = x; this.y = y; this.defX = x; this.defY = y;
        this.background = hasBackground ? add(new BoolSetting("Background", true)) : null;
    }

    @Override public final boolean isHud() { return true; }

    /** Unscaled size of the content. */
    public abstract int width();
    public abstract int height();
    protected abstract void draw(GuiGraphicsExtractor g, Minecraft mc);

    public int scaledWidth() { return Math.max(8, Math.round(width() * scale)); }
    public int scaledHeight() { return Math.max(8, Math.round(height() * scale)); }

    public final void render(GuiGraphicsExtractor g, Minecraft mc) {
        clamp(mc);
        var pose = g.pose();
        pose.pushMatrix();
        pose.translate((float) x, (float) y);
        pose.scale(scale, scale);
        draw(g, mc);
        pose.popMatrix();
    }

    public void clamp(Minecraft mc) {
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        x = Math.max(0, Math.min(x, sw - scaledWidth()));
        y = Math.max(0, Math.min(y, sh - scaledHeight()));
    }

    public void resetPosition() {
        x = defX; y = defY; scale = 1f;
        ConfigManager.markDirty();
    }

    protected void backdrop(GuiGraphicsExtractor g, int w, int h) {
        if (background != null && background.get()) {
            Draw.round(g, 0, 0, w, h, 3, Draw.alpha(Theme.bg, 0.62f));
            g.fill(0, 3, 2, h - 3, Theme.accent);
        }
    }

    @Override public JsonObject save() {
        JsonObject o = super.save();
        o.addProperty("x", x);
        o.addProperty("y", y);
        o.addProperty("scale", scale);
        return o;
    }

    @Override public void load(JsonObject o) {
        super.load(o);
        try {
            if (o.has("x")) x = o.get("x").getAsInt();
            if (o.has("y")) y = o.get("y").getAsInt();
            if (o.has("scale")) scale = Math.max(0.5f, Math.min(3f, o.get("scale").getAsFloat()));
        } catch (RuntimeException ignored) {}
    }
}
