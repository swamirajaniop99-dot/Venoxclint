package dev.venox.module.gameplay;

import dev.venox.input.Keys;
import dev.venox.module.Category;
import dev.venox.module.Module;
import dev.venox.setting.NumberSetting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

/** Hold the zoom key to lower the FOV. Vanilla's FOV option is limited to 30-110, so zoom bottoms out at 30. */
public final class ZoomModule extends Module {
    private final KeyMapping zoomKey = Keys.create("zoom", GLFW.GLFW_KEY_C);
    private final NumberSetting zoomFov = add(new NumberSetting("Zoom FOV", 30, 30, 70, 1));
    private boolean zooming;
    private int savedFov;

    public ZoomModule() { super("zoom", "Zoom", "Hold the zoom key (default C) to zoom in.", Category.GAMEPLAY, true); }

    @Override public void onTick(Minecraft mc) {
        boolean want = zoomKey.isDown() && mc.gui.screen() == null;
        if (want) {
            if (!zooming) { savedFov = mc.options.fov().get(); zooming = true; }
            mc.options.fov().set(zoomFov.getInt());
        } else {
            restore(mc);
        }
    }

    @Override public void onDisable() { restore(Minecraft.getInstance()); }
    @Override public void onShutdown() { restore(Minecraft.getInstance()); }

    private void restore(Minecraft mc) {
        if (zooming) { mc.options.fov().set(savedFov); zooming = false; }
    }
}
