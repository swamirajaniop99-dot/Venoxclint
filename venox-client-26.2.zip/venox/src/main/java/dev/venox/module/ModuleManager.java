package dev.venox.module;

import com.google.gson.JsonObject;
import dev.venox.input.Keys;
import dev.venox.module.gameplay.FullbrightModule;
import dev.venox.module.gameplay.ToggleSprintModule;
import dev.venox.module.gameplay.ZoomModule;
import dev.venox.module.hud.ArmorModule;
import dev.venox.module.hud.CoordinatesModule;
import dev.venox.module.hud.CpsModule;
import dev.venox.module.hud.FpsModule;
import dev.venox.module.hud.KeystrokesModule;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    /** Adding a module = one line here. */
    public static void init() {
        register(new FpsModule());
        register(new CpsModule());
        register(new KeystrokesModule());
        register(new ArmorModule());
        register(new CoordinatesModule());
        register(new ToggleSprintModule());
        register(new ZoomModule());
        register(new FullbrightModule());
    }

    private static void register(Module m) {
        m.toggleKey = Keys.create("module_" + m.id, GLFW.GLFW_KEY_UNKNOWN);
        MODULES.add(m);
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    public static List<Module> search(String query) {
        String q = query.toLowerCase(Locale.ROOT).trim();
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.name.toLowerCase(Locale.ROOT).contains(q)
                    || m.description.toLowerCase(Locale.ROOT).contains(q)
                    || m.category.label.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        }
        return out;
    }

    public static void tick(Minecraft mc) {
        for (Module m : MODULES) {
            while (m.toggleKey != null && m.toggleKey.consumeClick()) {
                if (mc.gui.screen() == null) m.toggle();
            }
            if (m.isEnabled()) m.onTick(mc);
        }
    }

    public static void shutdown() {
        for (Module m : MODULES) m.onShutdown();
    }

    public static void resetHudPositions() {
        for (Module m : MODULES) if (m instanceof HudModule h) h.resetPosition();
    }

    public static JsonObject save() {
        JsonObject o = new JsonObject();
        for (Module m : MODULES) o.add(m.id, m.save());
        return o;
    }

    public static void load(JsonObject o) {
        for (Module m : MODULES) {
            if (o.has(m.id) && o.get(m.id).isJsonObject()) m.load(o.getAsJsonObject(m.id));
        }
    }
}
