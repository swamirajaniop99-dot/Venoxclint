package dev.venox.module;

public enum Category {
    HUD("HUD"), GAMEPLAY("Gameplay"), VISUAL("Visual");

    public final String label;

    Category(String label) { this.label = label; }
}
