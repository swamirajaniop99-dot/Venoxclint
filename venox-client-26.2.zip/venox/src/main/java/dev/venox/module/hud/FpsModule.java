package dev.venox.module.hud;

import dev.venox.gui.Draw;
import dev.venox.gui.Theme;
import dev.venox.module.HudModule;
import dev.venox.setting.BoolSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class FpsModule extends HudModule {
    private final BoolSetting label = add(new BoolSetting("Show label", true));
    private final BoolSetting colorize = add(new BoolSetting("Color by FPS", true));
    private int frames, fps;
    private long windowStart = System.nanoTime();

    public FpsModule() { super("fps", "FPS Counter", "Shows your current frame rate.", 6, 6, true, true); }

    @Override public int width() { return PAD * 2 + (label.get() ? Draw.width("FPS ") : 0) + Draw.width(Integer.toString(fps)); }
    @Override public int height() { return PAD * 2 + 9; }

    @Override protected void draw(GuiGraphicsExtractor g, Minecraft mc) {
        frames++;
        long now = System.nanoTime(), el = now - windowStart;
        if (el >= 500_000_000L) { fps = (int) (frames * 1_000_000_000L / el); frames = 0; windowStart = now; }
        backdrop(g, width(), height());
        int x = PAD;
        if (label.get()) { Draw.text(g, "FPS", x, PAD, Theme.accent2); x += Draw.width("FPS "); }
        int c = !colorize.get() ? Theme.text() : fps >= 60 ? 0xFF4ADE80 : fps >= 30 ? 0xFFFACC15 : 0xFFF87171;
        Draw.text(g, Integer.toString(fps), x, PAD, c);
    }
}
