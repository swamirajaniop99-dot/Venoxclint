package dev.venox.module.hud;

import dev.venox.compat.ItemDraw;
import dev.venox.gui.Draw;
import dev.venox.gui.Theme;
import dev.venox.module.HudModule;
import dev.venox.setting.BoolSetting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public final class ArmorModule extends HudModule {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private final BoolSetting durability = add(new BoolSetting("Show durability", true));
    private final BoolSetting showEmpty = add(new BoolSetting("Show empty slots", false));

    public ArmorModule() { super("armor", "Armor HUD", "Shows worn armor with durability.", 6, 60, true, true); }

    private List<ItemStack> stacks(Minecraft mc) {
        List<ItemStack> out = new ArrayList<>();
        if (mc.player == null) return out;
        for (EquipmentSlot s : SLOTS) {
            ItemStack st = mc.player.getItemBySlot(s);
            if (!st.isEmpty() || showEmpty.get()) out.add(st);
        }
        return out;
    }

    @Override public int width() { return PAD * 2 + 16 + (durability.get() ? 4 + Draw.width("000") : 0); }
    @Override public int height() { return PAD * 2 + Math.max(1, stacks(Minecraft.getInstance()).size()) * 18 - 2; }

    @Override protected void draw(GuiGraphicsExtractor g, Minecraft mc) {
        backdrop(g, width(), height());
        int y = PAD;
        for (ItemStack st : stacks(mc)) {
            if (!st.isEmpty()) {
                ItemDraw.draw(g, mc.font, st, PAD, y);
                if (durability.get() && st.isDamageableItem()) {
                    int left = st.getMaxDamage() - st.getDamageValue();
                    float ratio = left / (float) st.getMaxDamage();
                    int c = Draw.lerp(0xFFF87171, 0xFF4ADE80, ratio);
                    Draw.text(g, Integer.toString(left), PAD + 20, y + 4, c);
                }
            }
            y += 18;
        }
    }
}
