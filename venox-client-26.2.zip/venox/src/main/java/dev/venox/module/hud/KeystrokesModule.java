package dev.venox.module.hud;

import dev.venox.gui.Draw;
import dev.venox.gui.Theme;
import dev.venox.module.HudModule;
import dev.venox.setting.BoolSetting;
import dev.venox.util.Anim;
import dev.venox.util.ClickTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class KeystrokesModule extends HudModule {
    private static final int K = 18, G = 2, SPACE_H = 12;
    private final BoolSetting mouse = add(new BoolSetting("Mouse buttons", true));
    private final ClickTracker tracker = new ClickTracker();
    private final float[] fade = new float[7];

    public KeystrokesModule() { super("keystrokes", "Keystrokes", "Shows WASD, jump and mouse buttons as you press them.", 6, 120, false, false); }

    @Override public int width() { return 3 * K + 2 * G; }
    @Override public int height() { return 2 * K + 2 * G + SPACE_H + (mouse.get() ? G + K : 0); }

    @Override protected void draw(GuiGraphicsExtractor g, Minecraft mc) {
        var o = mc.options;
        boolean l = o.keyAttack.isDown(), r = o.keyUse.isDown();
        tracker.update(l, r);
        key(g, K + G, 0, K, K, "W", 0, o.keyUp.isDown());
        key(g, 0, K + G, K, K, "A", 1, o.keyLeft.isDown());
        key(g, K + G, K + G, K, K, "S", 2, o.keyDown.isDown());
        key(g, 2 * (K + G), K + G, K, K, "D", 3, o.keyRight.isDown());
        key(g, 0, 2 * (K + G), width(), SPACE_H, "SPACE", 4, o.keyJump.isDown());
        if (mouse.get()) {
            int y = 2 * (K + G) + SPACE_H + G, w = (width() - G) / 2;
            key(g, 0, y, w, K, "L " + tracker.left(), 5, l);
            key(g, w + G, y, w, K, "R " + tracker.right(), 6, r);
        }
    }

    private void key(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, int idx, boolean down) {
        fade[idx] = Anim.approach(fade[idx], down ? 1f : 0f, 22f);
        int col = Draw.lerp(Draw.alpha(Theme.bg, 0.62f), Draw.alpha(Theme.accent, 0.88f), fade[idx]);
        Draw.round(g, x, y, w, h, 3, col);
        Draw.centered(g, label, x + w / 2, y + (h - 8) / 2, Draw.lerp(Theme.dim(), 0xFFFFFFFF, fade[idx]));
    }
}
