package dev.venox.module.gameplay;

import dev.venox.module.Category;
import dev.venox.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Client-side infinite Night Vision effect (the vanilla gamma slider cannot exceed 100%). */
public final class FullbrightModule extends Module {
    public FullbrightModule() { super("fullbright", "Fullbright", "Maximum visibility everywhere (client-side night vision).", Category.VISUAL, false); }

    @Override public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        if (mc.player.getEffect(MobEffects.NIGHT_VISION) == null) {
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, MobEffectInstance.INFINITE_DURATION, 0, false, false, false));
        }
    }

    @Override public void onDisable() { remove(Minecraft.getInstance()); }
    @Override public void onShutdown() { remove(Minecraft.getInstance()); }

    private void remove(Minecraft mc) {
        if (mc.player == null) return;
        MobEffectInstance cur = mc.player.getEffect(MobEffects.NIGHT_VISION);
        if (cur != null && cur.isInfiniteDuration()) mc.player.removeEffect(MobEffects.NIGHT_VISION);
    }
}
