package dev.venox.module;

import com.google.gson.JsonObject;
import dev.venox.config.ConfigManager;
import dev.venox.setting.Setting;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/** Base class. Modules are state-driven and independent: they never reference each other. */
public abstract class Module {
    public final String id, name, description;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();
    public KeyMapping toggleKey; // assigned by ModuleManager

    private boolean enabled;

    protected Module(String id, String name, String description, Category category, boolean enabledByDefault) {
        this.id = id; this.name = name; this.description = description; this.category = category;
        this.enabled = enabledByDefault;
    }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        ConfigManager.markDirty();
        if (v) onEnable(); else onDisable();
    }

    public void toggle() { setEnabled(!enabled); }

    public boolean isHud() { return false; }

    /** Called when enabled by the user. Must tolerate mc.player == null. */
    public void onEnable() {}
    /** Called when disabled by the user. Must restore any state the module changed. */
    public void onDisable() {}
    /** Called every client tick while enabled. */
    public void onTick(Minecraft mc) {}
    /** Called once when the game closes, regardless of enabled state. */
    public void onShutdown() {}

    public JsonObject save() {
        JsonObject o = new JsonObject();
        o.addProperty("enabled", enabled);
        JsonObject s = new JsonObject();
        for (Setting<?> st : settings) s.add(st.name, st.toJson());
        o.add("settings", s);
        return o;
    }

    public void load(JsonObject o) {
        if (o.has("enabled")) enabled = o.get("enabled").getAsBoolean(); // no hooks: modules are state-driven
        if (o.has("settings") && o.get("settings").isJsonObject()) {
            JsonObject s = o.getAsJsonObject("settings");
            for (Setting<?> st : settings) if (s.has(st.name)) st.fromJson(s.get(st.name));
        }
    }
}
