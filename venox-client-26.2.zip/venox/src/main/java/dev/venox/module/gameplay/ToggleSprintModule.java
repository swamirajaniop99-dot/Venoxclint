package dev.venox.module.gameplay;

import dev.venox.module.Category;
import dev.venox.module.Module;
import dev.venox.setting.BoolSetting;
import net.minecraft.client.Minecraft;

/** Holds the sprint key down for you while you walk forward. */
public final class ToggleSprintModule extends Module {
    private final BoolSetting needForward = add(new BoolSetting("Only while moving forward", true));
    private boolean forced;

    public ToggleSprintModule() { super("togglesprint", "Toggle Sprint", "Sprints automatically while you move forward.", Category.GAMEPLAY, true); }

    @Override public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        boolean want = mc.gui.screen() == null && (!needForward.get() || mc.options.keyUp.isDown()) && !mc.player.isShiftKeyDown();
        if (want) { mc.options.keySprint.setDown(true); forced = true; }
        else release(mc);
    }

    @Override public void onDisable() { release(Minecraft.getInstance()); }
    @Override public void onShutdown() { release(Minecraft.getInstance()); }

    private void release(Minecraft mc) {
        if (forced) { mc.options.keySprint.setDown(false); forced = false; }
    }
}
