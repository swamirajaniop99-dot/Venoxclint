package dev.venox.module.hud;

import dev.venox.gui.Draw;
import dev.venox.gui.Theme;
import dev.venox.module.HudModule;
import dev.venox.setting.BoolSetting;
import dev.venox.setting.NumberSetting;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class CoordinatesModule extends HudModule {
    private final NumberSetting decimals = add(new NumberSetting("Decimals", 1, 0, 3, 1));
    private final BoolSetting facing = add(new BoolSetting("Show facing", true));

    public CoordinatesModule() { super("coordinates", "Coordinates", "Shows XYZ position and facing direction.", 6, 150, true, true); }

    private String[] lines(Minecraft mc) {
        if (mc.player == null) return new String[] {"X 0", "Y 0", "Z 0"};
        String f = "%." + decimals.getInt() + "f";
        String x = String.format(Locale.ROOT, f, mc.player.getX());
        String y = String.format(Locale.ROOT, f, mc.player.getY());
        String z = String.format(Locale.ROOT, f, mc.player.getZ());
        if (!facing.get()) return new String[] {"X " + x, "Y " + y, "Z " + z};
        String d = mc.player.getDirection().getName();
        return new String[] {"X " + x, "Y " + y, "Z " + z, Character.toUpperCase(d.charAt(0)) + d.substring(1)};
    }

    @Override public int width() {
        int w = 0;
        for (String s : lines(Minecraft.getInstance())) w = Math.max(w, Draw.width(s));
        return PAD * 2 + Math.max(w, 48);
    }

    @Override public int height() { return PAD * 2 + lines(Minecraft.getInstance()).length * 11 - 2; }

    @Override protected void draw(GuiGraphicsExtractor g, Minecraft mc) {
        backdrop(g, width(), height());
        String[] ls = lines(mc);
        for (int i = 0; i < ls.length; i++) {
            boolean dir = facing.get() && i == 3;
            String s = ls[i];
            if (dir) { Draw.text(g, s, PAD, PAD + i * 11, Theme.accent2); continue; }
            Draw.text(g, s.substring(0, 1), PAD, PAD + i * 11, Theme.accent2);
            Draw.text(g, s.substring(1), PAD + Draw.width("X"), PAD + i * 11, Theme.text());
        }
    }
}
