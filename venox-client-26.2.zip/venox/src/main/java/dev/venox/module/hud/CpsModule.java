package dev.venox.module.hud;

import dev.venox.gui.Draw;
import dev.venox.gui.Theme;
import dev.venox.module.HudModule;
import dev.venox.setting.BoolSetting;
import dev.venox.util.ClickTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class CpsModule extends HudModule {
    private final BoolSetting showRight = add(new BoolSetting("Show right click", true));
    private final ClickTracker tracker = new ClickTracker();

    public CpsModule() { super("cps", "CPS Counter", "Clicks per second for attack/use buttons.", 6, 28, true, true); }

    private String text() { return tracker.left() + (showRight.get() ? " | " + tracker.right() : ""); }

    @Override public int width() { return PAD * 2 + Draw.width("CPS ") + Draw.width(text()); }
    @Override public int height() { return PAD * 2 + 9; }

    @Override protected void draw(GuiGraphicsExtractor g, Minecraft mc) {
        tracker.update(mc.options.keyAttack.isDown(), mc.options.keyUse.isDown());
        backdrop(g, width(), height());
        Draw.text(g, "CPS", PAD, PAD, Theme.accent2);
        Draw.text(g, text(), PAD + Draw.width("CPS "), PAD, Theme.text());
    }
}
